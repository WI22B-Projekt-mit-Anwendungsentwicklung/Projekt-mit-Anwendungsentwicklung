# WI22B-Anwendungsentwicklung-Funk
Projekt der Anwendungsentwicklung - 5. Semester - Prof. Dr. Funk - WI22B
